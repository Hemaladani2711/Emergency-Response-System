package com.example.ariel.emergencyresponse;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EditMedicalRecord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_medical_record);

    }
}
