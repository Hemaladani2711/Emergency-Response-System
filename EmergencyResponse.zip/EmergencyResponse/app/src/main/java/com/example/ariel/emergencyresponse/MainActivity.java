package com.example.ariel.emergencyresponse;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnPanick, btnCall911, btnSettings,btnEmergencyContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        assignObjects();
        btnCall911.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                Intent sIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:911"));
                sIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sIntent);}
                catch (SecurityException e){
                    e.printStackTrace();
                }
            }
        });

        btnPanick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startActivity=new Intent(MainActivity.this,PanicActivity.class);
                startActivity(startActivity);
            }
        });

        btnEmergencyContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startActivity=new Intent(MainActivity.this,EmergencyContacts.class);
                startActivity(startActivity);
            }
        });

        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startActivity=new Intent(MainActivity.this,Settings.class);
                startActivity(startActivity);
            }
        });


    }

    public void assignObjects(){
        btnPanick=(Button)findViewById(R.id.btnPanick);
        btnCall911=(Button)findViewById(R.id.btnCall911);
        btnSettings=(Button)findViewById(R.id.btnSettings);
        btnEmergencyContacts=(Button)findViewById(R.id.btnEmergencyContacts);

    }
}
